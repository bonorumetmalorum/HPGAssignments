Candidate: 201332107

Keyboard controls:
A - turn ambient on/off
D - turn diffuse on/off
S - turn specular on/off

mouse controls:
left click + drag to rotate
right click + drag to translate

path to obj file, ppm file and mtl file must be hard coded in the main.cpp file